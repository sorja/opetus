# Example for MiniBlog

Minimal code example for MiniBlog project

## Documentation links and frameworks
[Flask](http://flask.pocoo.org/)  
[Jinja2](http://jinja.pocoo.org/docs/2.10/)  
[Semantic UI](https://semantic-ui.com/)  

